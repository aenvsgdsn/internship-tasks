import json
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load NLP model
nlp = spacy.load("en_core_web_sm")

# Load FAQs
with open("faq_data.json", "r") as f:
    faq_data = json.load(f)

faq_questions = [item["question"] for item in faq_data]
faq_answers = [item["answer"] for item in faq_data]

# Preprocessing function
def preprocess(text):
    doc = nlp(text.lower())
    tokens = [token.lemma_ for token in doc if not token.is_stop and token.is_alpha]
    return " ".join(tokens)

# Preprocess all FAQ questions
processed_questions = [preprocess(q) for q in faq_questions]

# Vectorization
vectorizer = TfidfVectorizer()
faq_vectors = vectorizer.fit_transform(processed_questions)

# Chatbot response function
def get_response(user_input):
    user_processed = preprocess(user_input)
    user_vector = vectorizer.transform([user_processed])

    similarities = cosine_similarity(user_vector, faq_vectors)
    best_match = similarities.argmax()

    if similarities[0][best_match] < 0.3:
        return "Sorry, I couldn't understand your question."
    else:
        return faq_answers[best_match]

