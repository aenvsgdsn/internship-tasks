import tkinter as tk
from chatbot import get_response

def on_enter(event=None):
    user_msg = entry.get()
    if user_msg.strip():
        chat_log.config(state=tk.NORMAL)
        chat_log.insert(tk.END, "You: " + user_msg + "\n")
        response = get_response(user_msg)
        chat_log.insert(tk.END, "Bot: " + response + "\n\n")
        chat_log.config(state=tk.DISABLED)
        entry.delete(0, tk.END)

app = tk.Tk()
app.title("FAQ Chatbot")

chat_log = tk.Text(app, wrap=tk.WORD, state=tk.DISABLED, height=20, width=60)
chat_log.pack(padx=10, pady=10)

entry = tk.Entry(app, width=50)
entry.pack(padx=10, pady=(0, 10))
entry.bind("<Return>", on_enter)

send_button = tk.Button(app, text="Send", command=on_enter)
send_button.pack()

app.mainloop()

